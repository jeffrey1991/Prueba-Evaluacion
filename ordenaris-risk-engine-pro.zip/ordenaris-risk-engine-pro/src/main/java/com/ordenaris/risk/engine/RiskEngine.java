
package com.ordenaris.risk.engine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ordenaris.risk.model.DatosContables;
import com.ordenaris.risk.model.HistorialPagos;
import com.ordenaris.risk.model.RiskRequest;
import com.ordenaris.risk.model.RiskResponse;
import com.ordenaris.risk.model.VerificacionLegal;
import com.ordenaris.risk.provider.MockProviders;

@Service
public class RiskEngine {
	
	//Se injecta el servicio improvisado 
    private final MockProviders providers;

    public RiskEngine(MockProviders providers) {
        this.providers = providers;
    }

    //Metodo principal de asignar evaluaciones
    public RiskResponse evaluate(RiskRequest req) {

        DatosContables d = providers.getDatos(req.empresaId);
        HistorialPagos h = providers.getHistorial(req.empresaId);
        VerificacionLegal v = providers.getInfoLegal(req.empresaId);

        String risk = "BAJO";
        List<String> reglas = new ArrayList<>();

        // 1. Deuda activa
        if (h.deudaMayor90Dias) {
            return new RiskResponse("RECHAZADO",
                Arrays.asList("Deuda > 90 días"),
                "Deuda crítica");
        }

        // 2. Alta solicitud
        if (req.montoSolicitado.doubleValue() > d.ventasMensuales.doubleValue() * 8) {
            risk = "ALTO";
            reglas.add("Alta solicitud");
        }

        // 3. Empresa nueva
        if (d.mesesAntiguedad < 18 && risk.equals("BAJO")) {
            risk = "MEDIO";
            reglas.add("Empresa nueva");
        }

        // 4. Demanda legal
        if (v.juicioAbierto) {
            risk = "ALTO";
            reglas.add("Demanda legal");
        }

        // 5. Historial excelente
        if (h.ultimos12PagosPerfectos && risk.equals("ALTO")) {
            risk = "MEDIO";
            reglas.add("Historial excelente");
        }

        // 6. Producto estricto
        if (req.producto.equals("ARRENDAMIENTO_FINANCIERO")) {
            if (risk.equals("BAJO")) risk = "MEDIO";
            else if (risk.equals("MEDIO")) risk = "ALTO";
            reglas.add("Producto estricto");
        }

        return new RiskResponse(risk, reglas, "Evaluación completada");
    }
}
