package com.ordenaris.risk.model;

public class HistorialPagos {
    public boolean deudaMayor90Dias;
    public boolean ultimos12PagosPerfectos;
}
