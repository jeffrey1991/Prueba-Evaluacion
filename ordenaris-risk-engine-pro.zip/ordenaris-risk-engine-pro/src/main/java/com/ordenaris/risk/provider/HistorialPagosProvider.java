package com.ordenaris.risk.provider;

import com.ordenaris.risk.model.HistorialPagos;

public interface HistorialPagosProvider {
    HistorialPagos getHistorial(String empresaId);
}