package com.ordenaris.risk.provider;

import com.ordenaris.risk.model.VerificacionLegal;

public interface VerificacionLegalProvider {
    VerificacionLegal getInfoLegal(String empresaId);
}
