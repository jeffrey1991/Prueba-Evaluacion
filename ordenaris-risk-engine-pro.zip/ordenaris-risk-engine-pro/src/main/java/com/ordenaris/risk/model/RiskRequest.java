
package com.ordenaris.risk.model;
import java.math.BigDecimal;

public class RiskRequest {
  public String empresaId;
  public BigDecimal montoSolicitado;
  public String producto;
}
