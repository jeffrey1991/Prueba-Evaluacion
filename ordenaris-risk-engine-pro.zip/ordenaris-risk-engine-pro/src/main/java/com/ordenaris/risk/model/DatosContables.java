package com.ordenaris.risk.model;

import java.math.BigDecimal;

public class DatosContables {
    public BigDecimal ventasMensuales;
    public int mesesAntiguedad;
}