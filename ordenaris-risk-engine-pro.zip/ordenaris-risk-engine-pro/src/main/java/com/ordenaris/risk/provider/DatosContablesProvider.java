package com.ordenaris.risk.provider;

import com.ordenaris.risk.model.DatosContables;

public interface DatosContablesProvider {
    DatosContables getDatos(String empresaId);
}