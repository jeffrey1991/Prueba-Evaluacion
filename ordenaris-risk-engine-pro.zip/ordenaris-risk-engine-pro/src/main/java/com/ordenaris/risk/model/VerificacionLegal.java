package com.ordenaris.risk.model;

public class VerificacionLegal {
    public boolean juicioAbierto;
}
