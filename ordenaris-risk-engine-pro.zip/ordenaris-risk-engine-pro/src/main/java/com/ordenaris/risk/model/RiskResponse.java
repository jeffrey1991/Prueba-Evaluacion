
package com.ordenaris.risk.model;
import java.util.List;

public class RiskResponse {

    public String nivel;
    public List<String> reglas;
    public String motivo;

    public RiskResponse(String nivel, List<String> reglas, String motivo) {
        this.nivel = nivel;
        this.reglas = reglas;
        this.motivo = motivo;
    }
}
