package com.ordenaris.risk.provider;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.ordenaris.risk.model.DatosContables;
import com.ordenaris.risk.model.HistorialPagos;
import com.ordenaris.risk.model.VerificacionLegal;
///Servicio provicional 
@Component
public class MockProviders implements 
    DatosContablesProvider,
    HistorialPagosProvider,
    VerificacionLegalProvider {

    public DatosContables getDatos(String empresaId) {
        DatosContables d = new DatosContables();
        d.ventasMensuales = BigDecimal.valueOf(1000);
        d.mesesAntiguedad = 12;
        return d;
    }

    public HistorialPagos getHistorial(String empresaId) {
        HistorialPagos h = new HistorialPagos();
        h.deudaMayor90Dias = false;
        h.ultimos12PagosPerfectos = true;
        return h;
    }

    public VerificacionLegal getInfoLegal(String empresaId) {
        VerificacionLegal v = new VerificacionLegal();
        v.juicioAbierto = false;
        return v;
    }
}
