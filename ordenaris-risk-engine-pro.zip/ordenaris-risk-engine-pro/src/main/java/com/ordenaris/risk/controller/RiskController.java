
package com.ordenaris.risk.controller;

import org.springframework.web.bind.annotation.*;
import com.ordenaris.risk.engine.RiskEngine;
import com.ordenaris.risk.model.*;

//Se crea el controllador para recibir las peticiones con el contexto de /evaluate
@RestController
@RequestMapping("/evaluate")
public class RiskController {

	//Se hace una instancia de Risk para usar los metodos
  private final RiskEngine engine;

  public RiskController(RiskEngine engine){
    this.engine = engine;
  }

  //Se procesa la peticion de post recibiendo la peticion
  @PostMapping
  public RiskResponse evaluate(@RequestBody RiskRequest req){
      return engine.evaluate(req);
  }
}
